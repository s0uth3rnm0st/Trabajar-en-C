#include "cliente.h"
int altaCliente(int *cantidad,Cliente *listado[]);
int listarClientes(int cantidad,Cliente *listado[]);
